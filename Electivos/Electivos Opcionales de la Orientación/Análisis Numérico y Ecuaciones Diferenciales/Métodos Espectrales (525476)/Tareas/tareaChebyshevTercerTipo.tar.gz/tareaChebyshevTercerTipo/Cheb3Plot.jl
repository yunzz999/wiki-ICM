using Plots

p = plot()
t = range(-0.9999, 1, length=128)
for k = 0:5
	plot!(p, t, cos.((k+0.5)*acos.(t))./(cos.(0.5*acos.(t))), linewidth=2, xlims=[-1, 1], ylims=[-7, 6], label="\$V_"*string(k)*"\$", framestyle=:origin, size=(480,320))
end
savefig(p, "Cheb3Plot.pdf")
